package hospital_management_system;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Naveed
 */
public class Node {
     String data="";
    Node next=null;
    public void displaynode(){
        System.out.println(data+"\n");
    }
    
}
